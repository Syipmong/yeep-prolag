# Yeep v2.0.0 - Windows Release Package 
 
## Installation 
1. Run `install.bat` to install Yeep 
2. Add %USERPROFILE%\bin to your PATH if needed 
3. Open a new command prompt and run `yeep --version` 
 
## Quick Start 
```cmd 
yeep                     # Start interactive REPL 
yeep examples\demo_v2.yeep  # Run demo script 
``` 
